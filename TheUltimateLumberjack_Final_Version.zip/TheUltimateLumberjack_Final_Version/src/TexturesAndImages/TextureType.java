package TexturesAndImages;

public enum TextureType {
    grass, house
}
