package AnimationSettings;

public enum TypeOfAnAnimation {
    idle,walk,destroy
}
