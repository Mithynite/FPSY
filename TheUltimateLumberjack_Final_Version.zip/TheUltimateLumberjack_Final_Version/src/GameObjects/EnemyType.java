package GameObjects;

public enum EnemyType {
    Bandit, Villager
}
