package GameObjects;

public enum PlayerUpgrades {
    HP, Speed, Damage
}
